<?php
session_start();
include('config.php');
$uname=$_POST['uname'];
$pword=$_POST['pword'];
if(trim($uname,'')==" "){
  $status='uname';
} else if (trim($pword,'') == "") {
  $status="pword";
} else {
  $getData=mysql_query("SELECT * FROM `users` WHERE email='$uname' and pword='$pword'") or die(mysql_error());
  if (mysql_num_rows($getData) > 0)
  {
    $_SESSION["proj-session"] = $uname;
    $status = '1';
  }
  else {
    $status= '0';
  }
}
echo json_encode(array('status'=>$status));
?>
