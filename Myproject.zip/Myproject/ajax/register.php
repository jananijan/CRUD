<?php
session_start();
include('config.php');
//echo json_encode(array('status'=>$status));
$checkExist =mysql_query("SELECT * FROM `users` WHERE email='$_POST[email]'") or die(mysql_error());
if(mysql_num_rows($checkExist) > 0) {
    $status ='exist';
} else {
    $insData = "INSERT INTO `users`(`uname`, `email`, `pword`, `verification`,`status`) VALUES ('$_POST[uname]','$_POST[email]','$_POST[pword]','1','1')";  
if (!mysql_query($insData))
  {
    $status = '0';
  die('Error: ' . mysql_error());
  } else {
   $status = '1';   
  }
}

  echo json_encode(array('status'=>$status));

?>
    