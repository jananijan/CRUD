function loginCheck() {
    var uname = $("#login-email").val();
    var pword = $("#login-pword").val();
    $.ajax({
        url: "ajax/loginCheck.php",
        type: "post",
        dataType: 'json',
        data: 'uname=' + uname + "&pword=" + pword,
        success: function (data) {
            console.log(data);
            if (data.status == 'uname') {
               alert('username is Required');
                return false;

            } else if (data.status == 'pword') {
                alert('Password is Required');
                  return false;

            } else if (data.status == '0') {
               alert('username or password is wrong');
                  return false;

            } else {
                alert('login successfully');
                window.location = "dashboard.php";
                return true;
            }
        },
        error: function (data) {
            console.log(data);
        }
    });
}
function saveEmployee() {
    var ename = $("#ename").val();
    var dep = $("#dep").val();
    var clg =$("#clg").val();
    var salary = $("#salary").val();
    var jdate = $("#jDate").val();
    var dateval = /^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
    if(ename == '') {
        alert('Employee Name is Required');
    } else if(dep == '') {
        alert('Deparment is Required');
    } else if(clg == '') {
        alert('clgname is Required');
    } else if(salary == '') {
        alert('mobile no is Required');
    } else if(jdate == '') {
        alert('Date is Required');
    } else if(!dateval.test(jdate)) {
        alert('Date Enter DD/MM/YYYY')
    } else {
    $.ajax({
        url: "ajax/addEmployee.php",
        type: "post",
        dataType: 'json',
        data: 'empname=' +ename+"&dep=" + dep + '&salary='+salary+'&jdate='+jdate+'&clg='+clg,
        success: function (data) {
            console.log(data);
            if(data.status == '1') {
                document.getElementById("showError").style.display = "none";
                document.getElementById("showSuccess").style.display = "block";
                setTimeout(function(){
                document.getElementById("showSuccess").style.display = "none";
                },3000)
                $('#ename').removeAttr('value');
                $('#dep').removeAttr('value');
                $('#clg').removeAttr('value');
                $('#salary').removeAttr('value');
                $('#jDate').removeAttr('value');

            } else {
                document.getElementById("showSuccess").style.display = "none";
                document.getElementById("showError").style.display = "block";
                setTimeout(function(){
                document.getElementById("showError").style.display = "none";
                },3000)
                return false;
                
            }
          location.reload();
        },
        error: function (data) {
            console.log(data);
        }
    });    
    }
    
}
function registerFunction() {
    var uname = $("#register-uname").val();
    var email = $("#register-email").val();
    var pword = $("#register-pword").val();
    var emailVal = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(uname == '') {
        alert('Username is Required');    
    } else if(email == '') {
        alert('Email is Required');    
    } else if(pword == '') {
        alert('Password is Required');
    } else if(!emailVal.test(email)) { 
        alert('Please Enter valid email');
    } else {
         $.ajax({
        url: "ajax/register.php",
        type: "post",
        dataType: 'json',
        data: 'uname=' +uname+"&email=" + email + '&pword='+pword,
        success: function (data) {
            console.log(data);
            if(data.status == '1') {
                document.getElementById("showError").style.display = "none";
                document.getElementById("showSuccess").style.display = "block";
                                document.getElementById("showErrorExist").style.display = "none";
                setTimeout(function(){
                document.getElementById("showSuccess").style.display = "none";
                },3000)
            } else if(data.status =='exist') {
                 document.getElementById("showSuccess").style.display = "none";
                document.getElementById("showError").style.display = "none";
                document.getElementById("showErrorExist").style.display = "block";
                setTimeout(function(){
                document.getElementById("showErrorExist").style.display = "none";
                },3000)   
            } else {
                document.getElementById("showSuccess").style.display = "none";
                document.getElementById("showError").style.display = "block";
                                document.getElementById("showErrorExist").style.display = "none";

                setTimeout(function(){
                document.getElementById("showError").style.display = "none";
                },3000)                
            }
//           location.reload();
        },
        error: function (data) {
            console.log(data);
        }
    });

    }
   }
function changeStatus() {
    var id=$("#pass-id").val();
    var status=$("#pass-status").val();
    if(status =='1') {
        curSta = '0';
    } else {
        curSta = '1';
    }
    $.ajax({
        url: "ajax/changeStatus.php",
        type: "post",
        dataType: 'json',
        data: 'id='+id +'&status='+curSta,
        success: function (data) {
            console.log(data);
            if(data.status == '1') {
                alert('Change status Successfully');
                location.reload();
            }
        },
        error: function (data) {
            console.log(data);
        }
    });
}
