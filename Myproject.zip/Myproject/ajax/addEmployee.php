<?php
session_start();
include('config.php');
//echo json_encode(array('status'=>$status));
$userId = $_SESSION['proj-session'];

$insData = mysql_query("INSERT INTO `employees`(`userId`,`ename`, `dep`, `clg`, `salary`,`jDate`,`rDate`,`status`) VALUES ('$userId','$_POST[empname]','$_POST[dep]', '$_POST[clg]', '$_POST[salary]', '$_POST[jdate]','-','1')") or die(mysql_error());  
if (!$insData)
  {
    $status = '0';
  } else {
   $status = '1';   
  }
  echo json_encode(array('status'=>$status));

?>
