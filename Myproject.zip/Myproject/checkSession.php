<?php 
session_start();
if(!isset($_SESSION['proj-session']) || empty($_SESSION['proj-session'])) {
   header('location:index.php');
}?>