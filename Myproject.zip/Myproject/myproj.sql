-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2019 at 09:19 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL,
  `userId` varchar(50) NOT NULL,
  `ename` varchar(50) NOT NULL,
  `dep` varchar(50) NOT NULL,
  `clg` varchar(50) NOT NULL,
  `salary` varchar(10) NOT NULL,
  `jDate` varchar(10) NOT NULL,
  `rDate` varchar(10) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `userId`, `ename`, `dep`, `clg`, `salary`, `jDate`, `rDate`, `status`) VALUES
(1, 'psira42@gmail.com', 'Thiru', 'Developer', '', '1200000', '22-01-2019', '-', 0),
(2, 'thiru@gmail.com', 'Madhu', 'CEO', '', '100000000', '01/01/1975', '-', 1),
(3, 'thiru@gmail.com', 'Perumal', 'nothing', '', '000000', '01/01/1997', '-', 1),
(4, 'thiru@gmail.com', 'thiru', 'mca', '', '1000', '03/06/1997', '-', 1),
(5, 'karthick@gmail.com', 'karthick', 'mca', '', '10000', '03/06/1997', '-', 0),
(6, 'karthick@gmail.com', 'jai', 'mca', '', '9944733407', '03/06/1997', '-', 1),
(7, 'karthick@gmail.com', 'sakthi', 'mca', 'stjjoseph', '9944733407', '03/06/1997', '-', 1),
(8, 'karthick@gmail.com', 'mr', 'bsc', 'st.josephs engineering college', '9944733407', '03/06/1997', '-', 1),
(9, 'blaky@gmail.com', 'raj', 'mca', 'stjoseph', '9944733407', '03/06/1997', '-', 1),
(10, 'paveen@gmail.com', 'praveen', 'mca', 'stjoseph', '9944733407', '03/06/1997', '-', 1),
(11, 'psira42@gmail.com', 'Shiva ', 'Micro Biology', 'SIET college', '1234567890', '03/06/1997', '-', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pword` varchar(50) NOT NULL,
  `verification` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uname`, `email`, `pword`, `verification`, `status`) VALUES
(1, 'siranjeevi', 'psira42@gmail.com', '123456', 1, 1),
(2, 'Thiruneeswaran', 'thiru@gmail.com', '123456', 1, 1),
(3, 'siva', 'siva@gmail.com', '123456', 1, 1),
(4, 'raj', 'raj@gmail.com', 'bossboss', 1, 1),
(5, 'karthick', 'karthick@gmail.com', 'boss123', 1, 1),
(6, 'raj', 'blaky@gmail.com', 'boss', 1, 1),
(7, 'praveen', 'paveen@gmail.com', '123456', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
