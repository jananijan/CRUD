<?php
session_start();
include('config.php');
//echo json_encode(array('status'=>$status));
$userId = $_SESSION['proj-session'];
$update = mysql_query("UPDATE `employees` SET `status`='$_POST[status]' WHERE `id`='$_POST[id]'") or die(mysql_error());
if (!$update)
  {
    $status = '0';
  } else {
   $status = '1';   
  }
  echo json_encode(array('status'=>$status));

?>
